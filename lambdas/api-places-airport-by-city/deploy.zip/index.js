const { Client } = require( "@googlemaps/google-maps-services-js" );

// Google Maps Client docs here: https://googlemaps.github.io/google-maps-services-js/

exports.handler = async ( event ) => {

    const client = new Client( {} )

    // test sample code

    client
        .elevation( {
            params: {
                locations: [ { lat: 45, lng: -110 } ],
                key: "asdf",
            },
            timeout: 1000, // milliseconds
        } )
        .then( ( r ) => {
            console.log( r.data.results[ 0 ].elevation );
        } )
        .catch( ( e ) => {
            console.log( e.response.data.error_message );
        } );

    // const response = {
    //     statusCode: 200,
    //     body: JSON.stringify( 'Hello from Lambda!' ),
    // };
    // return response;
};


