const axios = require( 'axios' );

exports.handler = async (event) => {

    let response = { statusCode: 400, body: JSON.stringify( "couldn't find an restaurant" ) };

    // get "place from post" 
    const body = JSON.parse( event.body )

    const place = body.place;

    const queryString = `${ place }`;

    try {
        const result = await axios.get(`https://maps.googleapis.com/maps/api/place/textsearch/json?query=food+in+los+angelos&key=${API_KEY}` );
        console.log( result.data )
        

        response = { statusCode: 200, body: JSON.stringify( result ) }

    } catch ( err ) {

        console.log( err )
    }
    return response;

    
};
